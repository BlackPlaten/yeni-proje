/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package tasitlarprojecalistirma;

/**
 *
 * @author User
 */
public class TasitlarProjeCalistirma {

    public static void main(String[] args) {      
        
       kullanici m1 = new kullanici();
       m1.kullaniciKayit();
       m1.girisYap();
       
    }
}
